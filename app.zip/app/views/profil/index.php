<div class="profil-form">
    <h1 class="card-title fw-bold text-center mb-4">User 1</h1>
    <div class="row">
        <div class="col-lg-6">
            <p class="text-center text-center">
                Lorem ipsum dolor sit amet.
                <a href="<?= BASEURL; ?>signin">Sign In</a>
                <a href="<?= BASEURL; ?>signup">Sign Up</a>
            </p>
        </div>
        <div class="col-lg-6">
            <h1 class="card-title fw-bold text-center mb-4">User 1</h1>
            <p class="text-center text-center">
                Lorem ipsum dolor sit amet.
            </p>
        </div>
    </div>
</div>